import psycopg2
import pandas as pd
conn = psycopg2.connect(
    database="phoenix_dev",
    user="phoenixdevuser",
    password="Ph0En!XdBu$er",
    host="phoenix-northeu-dev-db.postgres.database.azure.com",
    port=5432
)
cursor = conn.cursor()
database_schema = "uat90001"
AK0_file_path = "C:/Task/Filter_data/AK0_data.txt"
AK0_unmapped_data = "C:/Task/Filter_data/AK0_unmapped_data.txt"
print("Connection created successfully")
with open(AK0_file_path , "r") as file , open(AK0_unmapped_data , "w") as AK0_unmapped_file:
    print("Read client Apos file successfully from : " , AK0_file_path)
    master_query = f'SELECT "VYROBEKVOZ_OZN" , "TABLPOZICE" FROM {database_schema}."TABLPOZ"'
    cursor.execute(master_query)
    tablpoz_rows = cursor.fetchall()
    tablpoz_result_list = [list(row) for row in tablpoz_rows]
    query = f'SELECT "PP_DRUH" , "TEXT" FROM {database_schema}."PPDRUH"'
    cursor.execute(query)
    pp_druh_rows = cursor.fetchall()
    pp_druh_result_list = [list(row) for row in pp_druh_rows]

    total_records = 0
    inserted_records = 0

    for line in file:
        print("Line Count : " , total_records)
        total_records = total_records+1
        table_position = line[14 : 16].strip()
        brand_name = list(filter(lambda x : table_position in x , tablpoz_result_list ))
 
        if len(brand_name)>0:
           brand_name = brand_name[0][0]
        else:
             brand_name = ""
        if  brand_name != 'Z' and brand_name != 'B' and brand_name != '':       
            model_description = line[56:95].strip()
            if line.startswith('AK0'):
                
                PP_DRUH_value = str(line[10:12])
                replace_text = list(filter(lambda x : PP_DRUH_value in x , pp_druh_result_list ))
                if len(replace_text)>0:
                    replace_text = replace_text[0][1]
                else:
                    replace_text = ""
                job_no_4digit = line[6:10].strip()
                model_description = model_description.replace(replace_text, '')[0:26]             
                cursor.execute(
                    f'SELECT COUNT(*) FROM {database_schema}."PPSERVISNR" WHERE "VYROBEKVOZ_OZN" = %s AND "PP_SERVIS_NR" = %s', (brand_name, job_no_4digit))
                row_count = cursor.fetchone()[0]
                if row_count == 0:
                    inserted_records = inserted_records+1
                    print("Inserting Data into PPSERVISNR....")
                    cursor.execute(f'INSERT INTO {database_schema}."PPSERVISNR" ("VYROBEKVOZ_OZN" ,"PP_SERVIS_NR" , "TEXT") VALUES(%s ,%s , %s );',
                                (brand_name, job_no_4digit, model_description,))
                    conn.commit()
                else:
                    AK0_unmapped_file.write(line)
    print("Total Records count for Ak0 " , total_records )
    print("Total Inserted Records In PPSERVISNR " , inserted_records)
                    
            


