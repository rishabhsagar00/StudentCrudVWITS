import psycopg2
import pandas as pd
conn = psycopg2.connect(
    database="phoenix_dev",
    user="phoenixdevuser",
    password="Ph0En!XdBu$er",
    host="phoenix-northeu-dev-db.postgres.database.azure.com",
    port=5432
)
cursor = conn.cursor()
database_schema = "uat90001"
master_file_path = "C:/Task/Master_Brand_Model_File.csv"
print("Connection created successfully")
data = pd.read_csv(master_file_path)
EDIT_PRAC_ID = 1
HOD_SZB_KOEF = 1
HOD_SZB_NAPO = 0
GAR_SZB_KOEF = 1
GAR_SZB_NAPO = 0

with open(master_file_path, 'r') as master_file:
    for master_line in master_file:
        print(master_line)
        master_line = master_line.split(',')
        if len(master_line[2]) != 1 or master_line[2] == 'Z' or master_line[2] == 'B':
            print("Skipping Record : ", master_line[2])
        else:
            cursor.execute(
                f'SELECT COUNT(*) FROM {database_schema}."TABLPOZ" WHERE "VYROBEKVOZ_OZN" = %s AND "TABLPOZICE" = %s', (master_line[2].strip(), master_line[0].strip()))
            row_count = cursor.fetchone()[0]
            master_line[1] = master_line[1][0:20]
            if row_count == 0 :
                    print("Inserting Data into TABLPOZ....")
                    query_master = f'INSERT INTO {database_schema}."TABLPOZ"("VYROBEKVOZ_OZN", "TABLPOZICE", "TEXT", "EDIT_PRAC_ID",  "HOD_SZB_KOEF", "HOD_SZB_NAPO", "GAR_SZB_KOEF", "GAR_SZB_NAPO") VALUES(%s , %s ,%s , %s, %s , %s , %s , %s)'
                    print(query_master)
                    cursor.execute(query_master , ((master_line[2].strip(), master_line[0].strip(), master_line[1].strip(),EDIT_PRAC_ID, HOD_SZB_KOEF, HOD_SZB_NAPO, GAR_SZB_KOEF, GAR_SZB_NAPO ,)))
                    conn.commit()
            else:
                print(f"Already exist with {master_line[0]}")
