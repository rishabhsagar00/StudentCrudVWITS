file_path = "C:/Task/Apos_data.txt"
AK0_file_path = "C:/Task/Filter_data/AK0_data.txt"
AK1_file_path = "C:/Task/Filter_data/AK1_data.txt"
with open(file_path , "r") as input_file , open(AK0_file_path , 'w') as AK0_output_file  , open(AK1_file_path , 'w') as AK1_output_file:
    # lines = file.readlines()
    print("Read client Apos file successfully from : " , file_path)
    for line in input_file:
        if line.startswith('AK0'):
            AK0_output_file.write(line)
        elif line.startswith('AK1'):
            AK1_output_file.write(line)
input_file.close()
AK0_output_file.close()
AK1_output_file.close()



