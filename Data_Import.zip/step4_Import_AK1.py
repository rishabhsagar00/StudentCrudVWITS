import psycopg2
import pandas as pd
conn = psycopg2.connect(
    database="phoenix_dev",
    user="phoenixdevuser",
    password="Ph0En!XdBu$er",
    host="phoenix-northeu-dev-db.postgres.database.azure.com",
    port=5432
)
cursor = conn.cursor()
database_schema = "uat90001"
AK1_unmapped_data = 'C:/Task/Filter_data/AK1_uninserted_data.txt'
AK1_file_path = "C:/Task/Filter_data/AK1_data.txt"
print("Connection created successfully")
with open(AK1_file_path , "r") as file , open(AK1_unmapped_data , "w") as AK1_unmapped_file :
    print("Read client Apos file successfully from : " , AK1_file_path)
    master_query = f'SELECT "VYROBEKVOZ_OZN" , "TABLPOZICE" FROM {database_schema}."TABLPOZ"'
    cursor.execute(master_query)
    tablpoz_rows = cursor.fetchall()
    tablpoz_result_list = [list(row) for row in tablpoz_rows]
    total_records = 0
    inserted_records = 0

    for line in file:
        print("Line Count : " , total_records)
        total_records = total_records+1
        table_position = line[14 : 16].strip()
        brand_name = list(filter(lambda x : table_position in x , tablpoz_result_list ))
        
        if len(brand_name)>0:
           brand_name = brand_name[0][0]
        else:
             brand_name = ""
        if table_position == '27':
            print("This is line for 27 position " , line)
        if  brand_name != 'Z' and brand_name != 'B' and brand_name != '':

            if line.startswith('AK1'):
                    inserted_records = inserted_records+1
                    DPH_SZB_OZN = 0
                    TABLPOZICE = line[14 : 16].strip()
                    CAS_JDN_POC = line[45:49].strip()
                    LAK_JDN_POC = 0
                    job_no_8digit = line[6:14].strip()
                    STRNAKLTYP_OZN = 1
                    SAC_CODE = 998729
                    cursor.execute(
                    f'SELECT COUNT(*) FROM {database_schema}."PPNR" WHERE "VYROBEKVOZ_OZN" = %s AND "PP_NR" = %s AND "TABLPOZICE" = %s', (brand_name, job_no_8digit , TABLPOZICE))
                    row_count = cursor.fetchone()[0]
                    if row_count == 0:  
                        cursor.execute(f'INSERT INTO {database_schema}."PPNR"("DPH_SZB_OZN" , "TABLPOZICE" , "CAS_JDN_POC" ,"LAK_JDN_POC" , "PP_NR" , "VYROBEKVOZ_OZN" ,"STRNAKLTYP_OZN" ,"SAC_CODE") VALUES(%s, %s, %s, %s, %s, %s, %s , %s);' , (DPH_SZB_OZN , TABLPOZICE , CAS_JDN_POC , LAK_JDN_POC , job_no_8digit, brand_name, STRNAKLTYP_OZN , SAC_CODE))
                        conn.commit()
                    else:
                         AK1_unmapped_file.write(line)
    print("Total Records count for Ak1 " , total_records )
    print("Total Inserted Records In PPNR " , inserted_records)
                    
            


